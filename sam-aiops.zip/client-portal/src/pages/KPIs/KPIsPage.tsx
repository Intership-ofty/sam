import React from 'react'
export default function KPIs() {
  return (
    <div className="grid">
      <div className="card">
        <h2>KPIs</h2>
        <p>Charts for NUR, uptime, MTTR, energy availability.</p>
      </div>
    </div>
  )
}
