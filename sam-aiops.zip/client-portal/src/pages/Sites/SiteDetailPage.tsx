import React from 'react'
export default function SiteDetail() {
  return (
    <div className="grid">
      <div className="card">
        <h2>Site Detail</h2>
        <p>Single site details, alarms and energy profile.</p>
      </div>
    </div>
  )
}
