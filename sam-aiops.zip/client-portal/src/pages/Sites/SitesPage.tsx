import React from 'react'
export default function Sites() {
  return (
    <div className="grid">
      <div className="card">
        <h2>Sites</h2>
        <p>List and filter sites by status/region.</p>
      </div>
    </div>
  )
}
