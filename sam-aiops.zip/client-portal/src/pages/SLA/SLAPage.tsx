import React from 'react'
export default function SLA() {
  return (
    <div className="grid">
      <div className="card">
        <h2>SLA</h2>
        <p>Targets configuration and export.</p>
      </div>
    </div>
  )
}
