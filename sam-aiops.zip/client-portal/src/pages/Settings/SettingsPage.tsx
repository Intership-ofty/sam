import React from 'react'
export default function Settings() {
  return (
    <div className="grid">
      <div className="card">
        <h2>Settings</h2>
        <p>Profile, notifications, and preferences.</p>
      </div>
    </div>
  )
}
