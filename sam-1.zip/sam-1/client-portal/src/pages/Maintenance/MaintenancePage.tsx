import React from 'react'
export default function Maintenance() {
  return (
    <div className="grid">
      <div className="card">
        <h2>Maintenance</h2>
        <p>Planned tasks and work orders.</p>
      </div>
    </div>
  )
}
