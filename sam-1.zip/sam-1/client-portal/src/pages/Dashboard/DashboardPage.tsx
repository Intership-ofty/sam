import React from 'react'
export default function Dashboard() {
  return (
    <div className="grid">
      <div className="card">
        <h2>Dashboard</h2>
        <p>KPIs overview, incidents and recent activity will be displayed here.</p>
      </div>
    </div>
  )
}
