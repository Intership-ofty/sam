import React from 'react'
export default function Alerts() {
  return (
    <div className="grid">
      <div className="card">
        <h2>Alerts</h2>
        <p>Live and historical alerts with filters.</p>
      </div>
    </div>
  )
}
