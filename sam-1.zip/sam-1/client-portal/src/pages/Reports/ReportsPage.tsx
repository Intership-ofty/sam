import React from 'react'
export default function Reports() {
  return (
    <div className="grid">
      <div className="card">
        <h2>Reports</h2>
        <p>Download SLA and monthly performance reports.</p>
      </div>
    </div>
  )
}
